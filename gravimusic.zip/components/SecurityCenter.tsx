
import React from 'react';
import { ShieldAlert, Zap, Lock, Eye, AlertTriangle } from 'lucide-react';

const SecurityCenter: React.FC = () => {
  return (
    <div className="p-10 h-full overflow-y-auto space-y-12 pb-20">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-white">Security Ops</h2>
          <p className="text-slate-500 font-medium">Active threat mitigation and intrusion detection</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="glass-panel p-8 rounded-[2rem] border-slate-800 border-red-500/20 bg-red-500/5">
                <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-red-500/10 flex items-center justify-center text-red-500">
                        <AlertTriangle size={24} />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-slate-600 uppercase">Critical Threats</p>
                        <p className="text-2xl font-black text-red-400">03 Detected</p>
                    </div>
                </div>
                <div className="space-y-4">
                    {[
                        'Brute force attempt on IP 82.3.1.2',
                        'Suspicious activity: User_4210',
                        'SSL Certificate expiring in 3 days'
                    ].map((t, i) => (
                        <div key={i} className="p-3 rounded-xl bg-red-500/5 border border-red-500/10 text-[10px] font-bold text-red-300">
                            {t}
                        </div>
                    ))}
                </div>
            </div>

            <div className="glass-panel p-8 rounded-[2rem] border-slate-800 col-span-2">
                <h3 className="font-bold flex items-center gap-3 mb-8">
                    <Zap size={18} className="text-amber-500" />
                    Intrusion Heatmap
                </h3>
                <div className="h-64 w-full bg-slate-900/50 rounded-2xl border border-slate-800 flex items-center justify-center">
                    <p className="text-slate-600 italic text-sm">Real-time attack vector visualization offline...</p>
                </div>
            </div>
        </div>

        <div className="glass-panel p-10 rounded-[2.5rem] border-slate-800 bg-gradient-to-br from-indigo-500/5 to-transparent">
            <h3 className="text-2xl font-black mb-8 flex items-center gap-4">
                <Lock size={28} className="text-indigo-400" />
                Auth Guard v2.0
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {[
                    { label: '2FA Adoption', val: '92%' },
                    { label: 'Avg Login Time', val: '1.2s' },
                    { label: 'Blocked IPs', val: '1,402' },
                    { label: 'Bot Detection', val: '99.9%' }
                ].map((s, i) => (
                    <div key={i} className="text-center md:text-left">
                        <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1">{s.label}</p>
                        <p className="text-4xl font-black text-white">{s.val}</p>
                    </div>
                ))}
            </div>
        </div>
    </div>
  );
};

export default SecurityCenter;
