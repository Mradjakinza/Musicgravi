
import React, { useEffect, useRef } from 'react';
import { 
  Play, Pause, SkipForward, SkipBack, Volume2, 
  Share2, Headphones, Layers, Mic2, FileText, 
  FastForward, Music
} from 'lucide-react';
import { useMusicStore } from '../store';
import { motion, AnimatePresence } from 'framer-motion';

const VerticalPlayer: React.FC = () => {
  const { 
    currentSong, isPlaying, setIsPlaying, volume, 
    nextSong, prevSong, isHiRes, toggleHiRes, isSpatial, toggleSpatial,
    playbackSpeed, setPlaybackSpeed, showLyrics, toggleLyrics, energyFilter
  } = useMusicStore();
  
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const render = () => {
      const data = (window as any).__GRAVI_AUDIO_DATA;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      if (data) {
        const barWidth = 3;
        const gap = 2;
        for (let i = 0; i < data.length; i += 2) {
          const barHeight = (data[i] / 255) * (canvas.width * 0.8);
          const x = (canvas.width - barHeight) / 2;
          const y = i * (barWidth + gap);
          const gradient = ctx.createLinearGradient(x, 0, x + barHeight, 0);
          gradient.addColorStop(0, '#8b5cf6');
          gradient.addColorStop(1, '#2dd4bf');
          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.roundRect(x, y, barHeight, barWidth, 4);
          ctx.fill();
        }
      }
      animationId = requestAnimationFrame(render);
    };
    render();
    return () => cancelAnimationFrame(animationId);
  }, []);

  const handleShareMood = () => {
    const text = `Current Vibe: Energy ${Math.round(energyFilter.x * 100)}%, Mood ${Math.round(energyFilter.y * 100)}%. Listening to ${currentSong?.title} on Gravimusic! 🚀`;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`, '_blank');
  };

  if (!currentSong) return null;

  return (
    <div className="w-24 h-full glass-panel border-l border-white/5 flex flex-col items-center py-8 z-40">
      {/* Dynamic Waveform Visualizer */}
      <div className="flex-1 w-full flex justify-center items-center py-4">
        <canvas 
          ref={canvasRef} 
          width={80} 
          height={200} 
          className="opacity-80 rotate-180"
        />
      </div>

      {/* Karaoke & Performance Controls */}
      <div className="flex flex-col gap-4 mb-6">
        <button 
          onClick={toggleLyrics}
          title="Toggle Lyrics"
          className={`p-3 rounded-xl transition-all ${showLyrics ? 'bg-[#8b5cf6] text-white shadow-[0_0_15px_#8b5cf6]' : 'bg-white/5 text-gray-400'}`}
        >
          <FileText size={20} />
        </button>
        
        <div className="relative group">
          <button 
            className="p-3 rounded-xl bg-white/5 text-gray-400 hover:text-white"
            onClick={() => setPlaybackSpeed(playbackSpeed === 1.0 ? 1.5 : (playbackSpeed === 1.5 ? 0.75 : 1.0))}
            title={`Speed: ${playbackSpeed}x`}
          >
            <span className="text-[10px] font-bold">{playbackSpeed}x</span>
          </button>
        </div>

        <button 
          onClick={toggleHiRes}
          title="Hi-Res Lossless"
          className={`p-3 rounded-xl transition-all ${isHiRes ? 'bg-[#2dd4bf] text-[#011618] shadow-[0_0_15px_#2dd4bf]' : 'bg-white/5 text-gray-400'}`}
        >
          <Layers size={20} />
        </button>
      </div>

      {/* Primary Playback Controls */}
      <div className="flex flex-col items-center gap-6 mb-8">
        <button onClick={prevSong} className="text-gray-400 hover:text-white transition-colors">
          <SkipBack size={24} />
        </button>
        
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-14 h-14 rounded-full bg-white text-[#011618] flex items-center justify-center shadow-[0_10px_30px_rgba(255,255,255,0.2)] hover:shadow-[0_10px_40px_rgba(255,255,255,0.3)] transition-all"
        >
          {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
        </motion.button>

        <button onClick={nextSong} className="text-gray-400 hover:text-white transition-colors">
          <SkipForward size={24} />
        </button>
      </div>

      {/* Volume Slider - Vertical */}
      <div className="group relative h-24 flex flex-col items-center mb-6">
        <div className="w-1 h-full bg-white/10 rounded-full relative overflow-hidden">
          <div 
            className="absolute bottom-0 w-full bg-[#2dd4bf] transition-all"
            style={{ height: `${volume * 100}%` }}
          />
        </div>
        <Volume2 size={16} className="mt-3 text-gray-500" />
      </div>

      <div className="mt-auto space-y-4">
        <button 
          onClick={handleShareMood}
          title="Share Mood"
          className="text-gray-500 hover:text-[#2dd4bf] transition-colors"
        >
          <Share2 size={20} />
        </button>
        <button 
          onClick={toggleSpatial}
          title="Spatial Audio"
          className={`p-2 rounded-lg transition-all ${isSpatial ? 'text-[#8b5cf6]' : 'text-gray-500'}`}
        >
          <Headphones size={20} />
        </button>
      </div>
    </div>
  );
};

export default VerticalPlayer;
