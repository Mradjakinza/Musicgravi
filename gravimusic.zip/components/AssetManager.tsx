
import React, { useState } from 'react';
import { useAdminStore } from '../store';
import { 
  Search, Filter, Plus, Trash2, Edit3, 
  MoreVertical, FileAudio, ExternalLink, RefreshCw 
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const AssetManager: React.FC = () => {
  const { queue, deleteSong, updateSong, addLog } = useAdminStore();
  const [isAiLoading, setIsAiLoading] = useState<string | null>(null);

  const handleAiDeepScan = async (songId: string) => {
    setIsAiLoading(songId);
    const song = queue.find(s => s.id === songId);
    if (!song) return;

    try {
      const ai = new GoogleGenAI({ apiKey: (process.env as any).API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze song: "${song.title}" by ${song.artist}. Categorize Energy (0-1) and Mood (0-1). Return JSON: {"energy": 0.5, "mood": 0.5}`,
        config: { responseMimeType: "application/json" }
      });
      
      const result = JSON.parse(response.text || '{}');
      updateSong(songId, { energy: result.energy, mood: result.mood });
      addLog(`AI Deep Scan complete for ID:${songId}. Recalibrated coordinates.`);
    } catch (e) {
      addLog(`ERROR: AI Scan failed for ID:${songId}`);
    } finally {
      setIsAiLoading(null);
    }
  };

  return (
    <div className="p-10 h-full flex flex-col space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black tracking-tighter">Global Asset Inventory</h2>
          <p className="text-slate-500 font-medium">Manage master track entries and metadata sync</p>
        </div>
        <button className="bg-white text-slate-950 px-6 py-3 rounded-xl font-black text-xs hover:bg-emerald-400 transition-colors shadow-xl">
          Ingest New Asset
        </button>
      </div>

      <div className="flex gap-4">
        <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
                type="text" 
                placeholder="Search global database by title, artist, or unique ID..."
                className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl pl-12 pr-6 py-4 outline-none focus:border-emerald-500/50 transition-all text-sm"
            />
        </div>
        <button className="px-6 py-4 rounded-2xl border border-slate-800 bg-slate-900/50 text-slate-400 hover:text-white transition-all flex items-center gap-3">
            <Filter size={18} />
            <span className="text-xs font-bold">Filter Assets</span>
        </button>
      </div>

      <div className="flex-1 glass-panel rounded-[2rem] border-slate-800 overflow-hidden flex flex-col">
        <div className="overflow-y-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-900/40 text-[10px] uppercase font-black text-slate-500 sticky top-0 z-10">
              <tr>
                <th className="px-8 py-5">Track Master</th>
                <th className="px-8 py-5">Bitrate</th>
                <th className="px-8 py-5">Coordinates</th>
                <th className="px-8 py-5">System ID</th>
                <th className="px-8 py-5 text-right">Operations</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {queue.map((song) => (
                <tr key={song.id} className="hover:bg-white/[0.02] transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-slate-800 overflow-hidden relative">
                        <img src={song.coverUrl} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                            <FileAudio size={16} />
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white leading-none mb-1">{song.title}</p>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">{song.artist}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-3 py-1 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-black uppercase">
                        {song.bitrate}
                    </span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                        <div className="space-y-1">
                            <div className="text-[9px] font-black text-slate-600 uppercase">Energy</div>
                            <div className="h-1 w-16 bg-slate-800 rounded-full overflow-hidden">
                                <div className="h-full bg-emerald-500" style={{ width: `${song.energy * 100}%` }} />
                            </div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-[9px] font-black text-slate-600 uppercase">Mood</div>
                            <div className="h-1 w-16 bg-slate-800 rounded-full overflow-hidden">
                                <div className="h-full bg-indigo-500" style={{ width: `${song.mood * 100}%` }} />
                            </div>
                        </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className="mono text-[10px] text-slate-600">GRAVI_00{song.id}_X</span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                            onClick={() => handleAiDeepScan(song.id)}
                            disabled={isAiLoading === song.id}
                            className={`p-2 rounded-lg hover:bg-emerald-500/10 text-emerald-500 transition-colors ${isAiLoading === song.id ? 'animate-pulse' : ''}`}
                            title="AI Deep Scan"
                        >
                            <RefreshCw size={16} className={isAiLoading === song.id ? 'animate-spin' : ''} />
                        </button>
                        <button className="p-2 rounded-lg hover:bg-white/5 text-slate-400 transition-colors">
                            <Edit3 size={16} />
                        </button>
                        <button 
                            onClick={() => deleteSong(song.id)}
                            className="p-2 rounded-lg hover:bg-red-500/10 text-red-400 transition-colors"
                        >
                            <Trash2 size={16} />
                        </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AssetManager;
