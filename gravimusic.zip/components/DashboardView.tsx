
import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Activity, Server, Cpu, Globe, ArrowUpRight, TrendingUp } from 'lucide-react';

const DashboardView: React.FC = () => {
  const metricData = useMemo(() => {
    return Array.from({ length: 24 }).map((_, i) => ({
      time: `${i}:00`,
      streams: Math.floor(Math.random() * 5000) + 1000,
      revenue: Math.floor(Math.random() * 200) + 50,
      cpu: Math.floor(Math.random() * 40) + 20,
    }));
  }, []);

  return (
    <div className="p-10 h-full overflow-y-auto space-y-10 pb-20">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-white">Mainframe Dashboard</h2>
          <p className="text-slate-500 font-medium">Real-time platform telemetry & global stream analytics</p>
        </div>
        <div className="flex gap-4">
            <button className="bg-emerald-500 text-slate-950 font-black text-xs px-6 py-3 rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-105 transition-transform flex items-center gap-2">
                <TrendingUp size={16} /> Generate Report
            </button>
        </div>
      </div>

      {/* Real-time Health Monitor */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Active Streams', value: '14,204', icon: Globe, color: 'text-emerald-400', bg: 'bg-emerald-400/5' },
          { label: 'Platform Revenue', value: '$84,203', icon: Activity, color: 'text-indigo-400', bg: 'bg-indigo-400/5' },
          { label: 'System CPU', value: '28.4%', icon: Cpu, color: 'text-amber-400', bg: 'bg-amber-400/5' },
          { label: 'Node Status', value: 'Healthy', icon: Server, color: 'text-blue-400', bg: 'bg-blue-400/5' },
        ].map((stat, i) => (
          <div key={i} className={`p-6 rounded-3xl border border-slate-800 ${stat.bg} relative overflow-hidden group hover:border-slate-700 transition-colors`}>
            <div className="flex justify-between items-start mb-4">
                <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest">{stat.label}</p>
                <stat.icon size={18} className={stat.color} />
            </div>
            <p className="text-3xl font-black mb-1">{stat.value}</p>
            <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-400">
                <ArrowUpRight size={12} /> +12.5% vs yesterday
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-panel p-8 rounded-[2rem] border-slate-800 h-[450px]">
           <div className="flex justify-between items-center mb-10">
                <h3 className="font-bold flex items-center gap-3">
                    <Activity size={18} className="text-emerald-400" />
                    Global Stream Velocity
                </h3>
                <select className="bg-slate-900 border border-slate-800 text-[10px] font-bold px-4 py-2 rounded-lg outline-none">
                    <option>Last 24 Hours</option>
                    <option>Last 7 Days</option>
                </select>
           </div>
           <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={metricData}>
                        <defs>
                            <linearGradient id="colorStreams" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.03)" />
                        <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 10}} />
                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#475569', fontSize: 10}} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }} />
                        <Area type="monotone" dataKey="streams" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorStreams)" />
                    </AreaChart>
                </ResponsiveContainer>
           </div>
        </div>

        <div className="glass-panel p-8 rounded-[2rem] border-slate-800">
           <h3 className="font-bold mb-8">System Health</h3>
           <div className="space-y-8">
                {[
                    { label: 'Main Database', status: 'Online', perf: 98 },
                    { label: 'Edge Caching', status: 'Online', perf: 100 },
                    { label: 'AI Processor', status: 'Warming', perf: 45 },
                    { label: 'Payment Gateway', status: 'Online', perf: 92 },
                ].map((node, i) => (
                    <div key={i} className="space-y-3">
                        <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-400">{node.label}</span>
                            <span className={`text-[10px] font-black uppercase ${node.perf > 80 ? 'text-emerald-500' : 'text-amber-500'}`}>{node.status}</span>
                        </div>
                        <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500" style={{ width: `${node.perf}%` }} />
                        </div>
                    </div>
                ))}
           </div>
           
           <div className="mt-12 p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/20">
                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2">Notice</p>
                <p className="text-xs text-slate-400 leading-relaxed">System scheduled for optimization in <span className="text-white font-bold">2h 14m</span>. No downtime expected.</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
