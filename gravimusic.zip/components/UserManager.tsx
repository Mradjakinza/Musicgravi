
import React from 'react';
import { useAdminStore } from '../store';
import { Shield, ShieldAlert, Mail, Clock, MoreHorizontal, UserCheck } from 'lucide-react';

const UserManager: React.FC = () => {
  const { users, updateUserStatus } = useAdminStore();

  return (
    <div className="p-10 h-full flex flex-col space-y-8">
        <div className="flex justify-between items-center">
            <div>
                <h2 className="text-4xl font-black tracking-tighter text-white">User Directory</h2>
                <p className="text-slate-500 font-medium">Manage access, permissions, and security flags</p>
            </div>
            <div className="flex gap-4">
                <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl flex items-center gap-4">
                    <UserCheck className="text-emerald-400" size={24} />
                    <div>
                        <p className="text-[10px] font-black text-slate-500 uppercase">Growth Rate</p>
                        <p className="text-xl font-black">+412 Today</p>
                    </div>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {users.map(user => (
                <div key={user.id} className="glass-panel p-8 rounded-[2rem] border-slate-800 relative group overflow-hidden">
                    <div className="flex justify-between items-start mb-6">
                        <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center font-black text-xl text-slate-300">
                            {user.name.charAt(0)}
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                            user.tier === 'Premium' ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' : 'bg-slate-800 text-slate-500 border border-slate-700'
                        }`}>
                            {user.tier}
                        </div>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-1">{user.name}</h3>
                    <div className="flex items-center gap-2 text-slate-500 text-xs mb-6">
                        <Mail size={12} />
                        {user.email}
                    </div>

                    <div className="flex items-center justify-between py-4 border-t border-slate-800/50">
                        <div className="flex items-center gap-2 text-[10px] text-slate-600 font-bold uppercase">
                            <Clock size={12} />
                            {user.lastSeen}
                        </div>
                        <div className={`flex items-center gap-1 text-[10px] font-black uppercase ${
                            user.status === 'Active' ? 'text-emerald-500' : user.status === 'Flagged' ? 'text-amber-500' : 'text-red-500'
                        }`}>
                            {user.status}
                        </div>
                    </div>

                    <div className="mt-4 flex gap-2 pt-4 border-t border-slate-800/50">
                        <button 
                            onClick={() => updateUserStatus(user.id, 'Banned')}
                            className="flex-1 py-3 rounded-xl bg-red-500/10 text-red-400 text-[10px] font-black uppercase hover:bg-red-500 hover:text-white transition-all"
                        >
                            Restrict
                        </button>
                        <button className="flex-1 py-3 rounded-xl bg-slate-800 text-slate-300 text-[10px] font-black uppercase hover:bg-white/10 transition-all">
                            Details
                        </button>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
};

export default UserManager;
