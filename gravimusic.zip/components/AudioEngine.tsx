
import React, { useEffect, useRef, useCallback } from 'react';
import { useMusicStore } from '../store';

const AudioEngine: React.FC = () => {
  const { 
    currentSong, isPlaying, volume, isHiRes, isSpatial, 
    playbackSpeed, setProgress, nextSong 
  } = useMusicStore();
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const pannerRef = useRef<PannerNode | null>(null);

  useEffect(() => {
    if (!audioRef.current) return;
    
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      analyserRef.current = audioContextRef.current.createAnalyser();
      gainNodeRef.current = audioContextRef.current.createGain();
      pannerRef.current = audioContextRef.current.createPanner();
      
      sourceRef.current = audioContextRef.current.createMediaElementSource(audioRef.current);
      
      sourceRef.current
        .connect(analyserRef.current)
        .connect(gainNodeRef.current)
        .connect(pannerRef.current)
        .connect(audioContextRef.current.destination);

      analyserRef.current.fftSize = 256;
      pannerRef.current.panningModel = 'HRTF';
    }
  }, []);

  // Sync state
  useEffect(() => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.play().catch(e => console.error("Playback failed", e));
      if (audioContextRef.current?.state === 'suspended') {
        audioContextRef.current.resume();
      }
    } else {
      audioRef.current.pause();
    }
  }, [isPlaying, currentSong]);

  useEffect(() => {
    if (gainNodeRef.current) {
      gainNodeRef.current.gain.value = volume;
    }
  }, [volume]);

  // Handle Playback Speed
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Note: Standard HTMLAudioElement doesn't support independent pitch shifting 
  // without changing speed easily. Advanced implementation would require 
  // AudioWorklet for Time Stretching/Pitch Shifting algorithms.
  // For this version, we'll note that speed affects pitch unless specialized.

  // Spatial Simulation
  useEffect(() => {
    if (pannerRef.current && audioContextRef.current) {
      if (isSpatial) {
        let angle = 0;
        const orbit = setInterval(() => {
          angle += 0.05;
          pannerRef.current?.setPosition(Math.sin(angle) * 5, 0, Math.cos(angle) * 5);
        }, 100);
        return () => clearInterval(orbit);
      } else {
        pannerRef.current.setPosition(0, 0, 0);
      }
    }
  }, [isSpatial]);

  const handleTimeUpdate = useCallback(() => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
    }
  }, [setProgress]);

  const handleEnded = useCallback(() => {
    nextSong();
  }, [nextSong]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (analyserRef.current) {
        const bufferLength = analyserRef.current.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        analyserRef.current.getByteFrequencyData(dataArray);
        (window as any).__GRAVI_AUDIO_DATA = dataArray;
        
        const avg = dataArray.reduce((a, b) => a + b, 0) / bufferLength;
        document.documentElement.style.setProperty('--aura-intensity', `${avg / 255}`);
      }
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <audio
      ref={audioRef}
      src={currentSong?.audioUrl}
      onTimeUpdate={handleTimeUpdate}
      onEnded={handleEnded}
      hidden
    />
  );
};

export default AudioEngine;
