
import React, { useState } from 'react';
import { useMusicStore } from '../store';
import { 
  Settings, Database, ShieldCheck, Save, Trash2, 
  Edit3, RefreshCw, Zap, Sliders, Palette, Info
} from 'lucide-react';
import { motion } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";

const AdminView: React.FC = () => {
  const { queue, updateSong, deleteSong, config, updateConfig } = useMusicStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // AI helper to optimize track coordinates
  const handleAiOptimize = async (songId: string) => {
    setIsAiLoading(true);
    const song = queue.find(s => s.id === songId);
    if (!song) return;

    try {
      // Use standardized initialization
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analyze this song metadata and suggest Energy (0-1) and Mood (0-1) coordinates for a mood grid. 
                  Song: "${song.title}" by ${song.artist}. Return ONLY JSON: {"energy": 0.5, "mood": 0.5}`,
        config: { responseMimeType: "application/json" }
      });
      
      // Access text property and trim
      const result = JSON.parse(response.text?.trim() || '{}');
      updateSong(songId, { energy: result.energy, mood: result.mood });
    } catch (e) {
      console.error("AI Optimization failed", e);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-10 space-y-12">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black tracking-tighter flex items-center gap-3">
            <ShieldCheck className="text-[#2dd4bf]" size={40} />
            Command Center
          </h2>
          <p className="text-gray-400 font-medium">Global platform orchestration & database control</p>
        </div>
        <div className="flex gap-4">
          <div className="glass-panel px-6 py-3 rounded-2xl flex items-center gap-3 border-white/10">
            <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-bold">Systems Nominal</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Platform Settings */}
        <section className="xl:col-span-1 space-y-6">
          <div className="glass-panel p-8 rounded-[2rem] border-white/10 bg-gradient-to-br from-white/5 to-transparent">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
              <Settings size={20} className="text-[#8b5cf6]" />
              General Config
            </h3>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black text-gray-500 tracking-widest ml-1">Platform Name</label>
                <input 
                  type="text" 
                  value={config.platformName}
                  onChange={(e) => updateConfig({ platformName: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-[#2dd4bf] outline-none transition-all"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                <div>
                  <p className="text-sm font-bold">Karaoke Engine</p>
                  <p className="text-[10px] text-gray-500">Enable real-time lyrics sync</p>
                </div>
                <button 
                  onClick={() => updateConfig({ enableKaraoke: !config.enableKaraoke })}
                  className={`w-12 h-6 rounded-full transition-all relative ${config.enableKaraoke ? 'bg-[#2dd4bf]' : 'bg-white/10'}`}
                >
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${config.enableKaraoke ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="space-y-4 pt-4">
                <p className="text-[10px] uppercase font-black text-gray-500 tracking-widest ml-1">Branding Palette</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl">
                    <input type="color" value={config.primaryColor} onChange={(e) => updateConfig({ primaryColor: e.target.value })} className="w-8 h-8 rounded-lg bg-transparent border-none" />
                    <span className="text-xs font-mono uppercase">{config.primaryColor}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/5 rounded-xl">
                    <input type="color" value={config.secondaryColor} onChange={(e) => updateConfig({ secondaryColor: e.target.value })} className="w-8 h-8 rounded-lg bg-transparent border-none" />
                    <span className="text-xs font-mono uppercase">{config.secondaryColor}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="glass-panel p-6 rounded-2xl border-white/10 border-dashed bg-red-500/5">
             <h4 className="text-red-400 text-xs font-bold uppercase mb-2 flex items-center gap-2">
               <Zap size={14} /> Danger Zone
             </h4>
             <button className="w-full py-3 rounded-xl border border-red-500/20 text-red-400 text-xs font-bold hover:bg-red-500 hover:text-white transition-all">
               Purge Cached Assets
             </button>
          </div>
        </section>

        {/* Database Management */}
        <section className="xl:col-span-2">
          <div className="glass-panel rounded-[2rem] border-white/10 overflow-hidden">
            <div className="p-8 border-b border-white/5 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <Database size={20} className="text-[#2dd4bf]" />
                  Asset Inventory
                </h3>
                <p className="text-xs text-gray-500">Manage all tracks currently in the global stream</p>
              </div>
              <div className="flex gap-2">
                <button className="p-2 bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors">
                  <RefreshCw size={18} />
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-[10px] uppercase font-black text-gray-500">
                  <tr>
                    <th className="px-8 py-4">Identity</th>
                    <th className="px-8 py-4">Energy Sync</th>
                    <th className="px-8 py-4">Mood Sync</th>
                    <th className="px-8 py-4 text-right">Ops</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {queue.map((song) => (
                    <tr key={song.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-8 py-4">
                        <div className="flex items-center gap-4">
                          <img src={song.coverUrl} className="w-10 h-10 rounded-xl" />
                          <div>
                            <p className="text-sm font-bold">{song.title}</p>
                            <p className="text-[10px] text-gray-500">{song.artist}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-4">
                        <div className="flex items-center gap-3">
                          <input 
                            type="range" min="0" max="1" step="0.01" 
                            value={song.energy}
                            onChange={(e) => updateSong(song.id, { energy: parseFloat(e.target.value) })}
                            className="w-24 accent-[#2dd4bf]"
                          />
                          <span className="text-[10px] font-mono text-gray-400">{song.energy.toFixed(2)}</span>
                        </div>
                      </td>
                      <td className="px-8 py-4">
                        <div className="flex items-center gap-3">
                          <input 
                            type="range" min="0" max="1" step="0.01" 
                            value={song.mood}
                            onChange={(e) => updateSong(song.id, { mood: parseFloat(e.target.value) })}
                            className="w-24 accent-[#8b5cf6]"
                          />
                          <span className="text-[10px] font-mono text-gray-400">{song.mood.toFixed(2)}</span>
                        </div>
                      </td>
                      <td className="px-8 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleAiOptimize(song.id)}
                            disabled={isAiLoading}
                            title="AI Optimize Gravity"
                            className="p-2 text-[#2dd4bf] hover:bg-[#2dd4bf]/10 rounded-lg transition-colors"
                          >
                            <RefreshCw size={16} className={isAiLoading ? 'animate-spin' : ''} />
                          </button>
                          <button 
                            onClick={() => deleteSong(song.id)}
                            className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AdminView;
