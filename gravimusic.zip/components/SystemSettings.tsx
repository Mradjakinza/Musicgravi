
import React from 'react';
import { useAdminStore } from '../store';
import { Settings, Shield, Globe, Palette, Save } from 'lucide-react';

const SystemSettings: React.FC = () => {
  const { config, updateConfig } = useAdminStore();

  return (
    <div className="p-10 h-full overflow-y-auto space-y-12">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-white">Core Configuration</h2>
          <p className="text-slate-500 font-medium">Adjust global platform parameters and infrastructure rules</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="glass-panel p-8 rounded-[2rem] border-slate-800 space-y-8">
                <h3 className="font-bold flex items-center gap-3">
                    <Globe size={18} className="text-emerald-500" />
                    General Settings
                </h3>
                
                <div className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-1">Platform Identity</label>
                        <input 
                            type="text" 
                            value={config.platformName}
                            onChange={(e) => updateConfig({ platformName: e.target.value })}
                            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-6 py-4 outline-none focus:border-emerald-500 transition-all"
                        />
                    </div>
                    <div className="flex items-center justify-between p-6 rounded-2xl bg-white/5 border border-white/5">
                        <div>
                            <p className="text-sm font-bold">Maintenance Engine</p>
                            <p className="text-[10px] text-slate-500">Enable global maintenance landing page</p>
                        </div>
                        <button 
                            onClick={() => updateConfig({ maintenanceMode: !config.maintenanceMode })}
                            className={`w-14 h-7 rounded-full transition-all relative ${config.maintenanceMode ? 'bg-amber-500' : 'bg-slate-700'}`}
                        >
                            <div className={`absolute top-1.5 w-4 h-4 rounded-full bg-white transition-all ${config.maintenanceMode ? 'right-1.5' : 'left-1.5'}`} />
                        </button>
                    </div>
                </div>
            </div>

            <div className="glass-panel p-8 rounded-[2rem] border-slate-800 space-y-8">
                <h3 className="font-bold flex items-center gap-3">
                    <Shield size={18} className="text-indigo-500" />
                    Security Protocols
                </h3>
                <div className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-1">Log Retention (Days)</label>
                        <input 
                            type="number" 
                            value={config.logRetentionDays}
                            onChange={(e) => updateConfig({ logRetentionDays: parseInt(e.target.value) })}
                            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-6 py-4 outline-none focus:border-indigo-500 transition-all"
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-slate-600 uppercase tracking-widest ml-1">Max Upload Threshold (MB)</label>
                        <input 
                            type="number" 
                            value={config.maxUploadSizeMb}
                            onChange={(e) => updateConfig({ maxUploadSizeMb: parseInt(e.target.value) })}
                            className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-6 py-4 outline-none focus:border-indigo-500 transition-all"
                        />
                    </div>
                </div>
            </div>

            <div className="lg:col-span-2 flex justify-end">
                <button className="bg-emerald-500 text-slate-950 font-black text-xs px-10 py-4 rounded-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 shadow-2xl shadow-emerald-500/20">
                    <Save size={18} />
                    Commit Core Changes
                </button>
            </div>
        </div>
    </div>
  );
};

export default SystemSettings;
