
import React, { useState, useEffect, useRef } from 'react';
import { useAdminStore } from '../store';

const AdminConsole: React.FC = () => {
  const { logs, addLog } = useAdminStore();
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const cmd = input.toLowerCase().trim();
    addLog(`> ${input}`);

    if (cmd === 'clear') {
      // Clear simulation handled by store if needed, here we just echo
      addLog('Console cleared.');
    } else if (cmd === 'help') {
      addLog('Available commands: status, restart-node, flush-cache, ping, whoami, help');
    } else if (cmd === 'ping') {
      addLog('PONG - Latency: 4ms');
    } else if (cmd === 'status') {
      addLog('Platform: Operational | Nodes: 4/4 Online | Database: Synced');
    } else {
      addLog(`Command not recognized: ${cmd}`);
    }

    setInput('');
  };

  return (
    <div className="p-10 h-full flex flex-col space-y-8">
        <div>
          <h2 className="text-4xl font-black tracking-tighter">System Terminal</h2>
          <p className="text-slate-500 font-medium tracking-tight">Direct kernel-level access to the Gravicore Engine</p>
        </div>

        <div className="flex-1 bg-black/80 rounded-3xl border border-slate-800 p-8 mono text-xs leading-relaxed flex flex-col overflow-hidden relative shadow-2xl">
            <div className="absolute top-0 left-0 right-0 h-8 bg-slate-900/50 border-b border-slate-800 flex items-center px-4 gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500/50" />
                <div className="w-2 h-2 rounded-full bg-amber-500/50" />
                <div className="w-2 h-2 rounded-full bg-emerald-500/50" />
                <span className="text-[10px] text-slate-500 ml-2">root@gravicore:~</span>
            </div>

            <div className="flex-1 overflow-y-auto mt-6 pr-4 space-y-1 custom-scrollbar">
                <p className="text-emerald-500 mb-4">GRAVICORE OS [Version 3.5.0-Complex]</p>
                <p className="text-slate-600 mb-6">(c) 2025 Gravimusic Inc. All rights reserved.</p>
                
                {logs.slice().reverse().map((log, i) => (
                    <div key={i} className="flex gap-4">
                        <span className="text-slate-700">[{i}]</span>
                        <span className={log.includes('ERROR') ? 'text-red-400' : log.startsWith('>') ? 'text-indigo-400 font-bold' : 'text-slate-300'}>
                            {log}
                        </span>
                    </div>
                ))}
                <div ref={bottomRef} />
            </div>

            <form onSubmit={handleCommand} className="mt-8 flex gap-3 items-center border-t border-slate-800/50 pt-4">
                <span className="text-emerald-500 font-bold">root#</span>
                <input 
                    autoFocus
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    className="flex-1 bg-transparent border-none outline-none text-white font-mono"
                    placeholder="Type 'help' for available commands..."
                />
            </form>
        </div>
    </div>
  );
};

export default AdminConsole;
