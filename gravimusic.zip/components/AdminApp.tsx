
import React from 'react';
import { useAdminStore } from '../store';
import { 
  Activity, Database, Users, ShieldAlert, Settings, 
  Terminal, ShieldCheck, ChevronRight, LogOut, Bell
} from 'lucide-react';
import DashboardView from './DashboardView';
import AssetManager from './AssetManager';
import UserManager from './UserManager';
import SecurityCenter from './SecurityCenter';
import SystemSettings from './SystemSettings';
import AdminConsole from './AdminConsole';
import { motion, AnimatePresence } from 'framer-motion';

const AdminApp: React.FC = () => {
  const { activeSection, setActiveSection, config } = useAdminStore();

  const NavItem = ({ section, icon: Icon, label }: { section: any, icon: any, label: string }) => (
    <button
      onClick={() => setActiveSection(section)}
      className={`flex items-center gap-4 w-full p-4 rounded-xl transition-all group ${
        activeSection === section 
        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.1)]' 
        : 'text-slate-500 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} className={activeSection === section ? 'text-emerald-400' : 'group-hover:text-white'} />
      <span className="font-bold text-sm tracking-tight">{label}</span>
      {activeSection === section && <ChevronRight size={14} className="ml-auto" />}
    </button>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard': return <DashboardView />;
      case 'assets': return <AssetManager />;
      case 'users': return <UserManager />;
      case 'security': return <SecurityCenter />;
      case 'settings': return <SystemSettings />;
      case 'console': return <AdminConsole />;
      default: return <DashboardView />;
    }
  };

  return (
    <div className="flex h-screen w-screen bg-[#020617] text-slate-200 overflow-hidden relative">
      <div className="scanline" />
      
      {/* Heavy-Duty Sidebar */}
      <aside className="w-80 border-r border-slate-800 flex flex-col p-8 bg-[#020617] relative z-20">
        <div className="flex items-center gap-4 mb-12 px-2">
          <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/30">
            <ShieldCheck className="text-white" size={28} />
          </div>
          <div>
            <h1 className="text-xl font-black text-white tracking-tighter leading-none">GRAVICORE</h1>
            <p className="text-[10px] text-emerald-500 font-black uppercase tracking-[0.2em] mt-1">v3.5.0-Complex</p>
          </div>
        </div>

        <div className="space-y-8 flex-1">
          <section>
            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4 px-2">Mainframe</p>
            <div className="space-y-1">
              <NavItem section="dashboard" icon={Activity} label="Overview" />
              <NavItem section="assets" icon={Database} label="Asset Inventory" />
              <NavItem section="users" icon={Users} label="User Directory" />
            </div>
          </section>

          <section>
            <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-4 px-2">Security & Core</p>
            <div className="space-y-1">
              <NavItem section="security" icon={ShieldAlert} label="Security Ops" />
              <NavItem section="console" icon={Terminal} label="Admin Console" />
              <NavItem section="settings" icon={Settings} label="System Config" />
            </div>
          </section>
        </div>

        <div className="mt-auto border-t border-slate-800 pt-8">
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/40 border border-slate-800 mb-6">
                <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center font-bold text-emerald-400">AD</div>
                <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold truncate">SuperUser_Root</p>
                    <p className="text-[10px] text-slate-500">Master Access</p>
                </div>
            </div>
          <button className="flex items-center gap-4 w-full p-4 rounded-xl text-red-400/80 hover:text-red-400 hover:bg-red-400/5 transition-all">
            <LogOut size={20} />
            <span className="font-bold text-sm">Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Primary Workspace */}
      <main className="flex-1 flex flex-col relative bg-slate-950/20 z-10">
        <header className="h-20 border-b border-slate-800/50 flex items-center justify-between px-10 bg-slate-900/10 backdrop-blur-md">
            <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Network: Nominal</span>
                </div>
                <div className="h-4 w-[1px] bg-slate-800" />
                <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-slate-500">Latency: 12ms</span>
                </div>
            </div>
            <div className="flex items-center gap-6">
                <button className="p-2 text-slate-500 hover:text-white relative">
                    <Bell size={20} />
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-[#020617]" />
                </button>
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-mono text-[10px]">v.ENG</div>
            </div>
        </header>

        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, scale: 0.99, y: 5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -5 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="h-full w-full"
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Ambient background noise */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.02] bg-[url('https://grainy-gradients.vercel.app/noise.svg')] mix-blend-overlay" />
    </div>
  );
};

export default AdminApp;
