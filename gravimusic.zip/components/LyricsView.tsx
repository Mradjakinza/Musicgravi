
import React, { useEffect, useRef } from 'react';
import { useMusicStore } from '../store';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic2, Share2, X } from 'lucide-react';

const LyricsView: React.FC = () => {
  const { currentSong, currentLyricIndex, showLyrics, toggleLyrics } = useMusicStore();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (currentLyricIndex !== -1 && scrollRef.current) {
      const activeLine = scrollRef.current.children[currentLyricIndex] as HTMLElement;
      if (activeLine) {
        activeLine.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [currentLyricIndex]);

  if (!showLyrics) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-12 bg-[#011618]/90 backdrop-blur-3xl"
    >
      <button 
        onClick={toggleLyrics}
        className="absolute top-8 right-8 p-4 rounded-full bg-white/5 text-white hover:bg-white/10 transition-colors"
      >
        <X size={24} />
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 w-full max-w-7xl h-full items-center">
        {/* Album Art & Track Info */}
        <div className="hidden lg:flex flex-col items-center text-center">
          <motion.div
            animate={{ 
              rotate: [0, 5, 0, -5, 0],
              scale: [1, 1.02, 1]
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
            className="w-full max-w-md aspect-square rounded-[3rem] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.8)] border border-white/10 mb-12"
          >
            <img src={currentSong?.coverUrl} className="w-full h-full object-cover" />
          </motion.div>
          <h2 className="text-4xl font-black mb-4 tracking-tighter">{currentSong?.title}</h2>
          <p className="text-xl text-[#2dd4bf] font-medium">{currentSong?.artist}</p>
          
          <div className="mt-8 flex gap-4">
             <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#8b5cf6]/20 border border-[#8b5cf6]/30 text-[#8b5cf6] text-xs font-bold uppercase tracking-widest">
               <Mic2 size={14} /> Karaoke Active
             </div>
          </div>
        </div>

        {/* Dynamic Lyrics Stream */}
        <div 
          ref={scrollRef}
          className="h-full overflow-y-auto pr-12 space-y-8 py-40 mask-fade"
          style={{ 
            maskImage: 'linear-gradient(to bottom, transparent, black 20%, black 80%, transparent)',
            WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 20%, black 80%, transparent)'
          }}
        >
          {currentSong?.lyrics?.map((line, idx) => (
            <motion.div
              key={idx}
              animate={{ 
                opacity: currentLyricIndex === idx ? 1 : 0.3,
                scale: currentLyricIndex === idx ? 1.1 : 1,
                x: currentLyricIndex === idx ? 20 : 0
              }}
              className={`text-4xl lg:text-5xl font-black leading-tight cursor-default transition-all duration-500 ${
                currentLyricIndex === idx 
                ? 'text-white' 
                : 'text-white/20 hover:text-white/40'
              }`}
            >
              {line.text}
            </motion.div>
          ))}
          {!currentSong?.lyrics && (
            <div className="text-center text-2xl text-gray-500 font-bold italic">
              Lyrics are unavailable for this track
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default LyricsView;
