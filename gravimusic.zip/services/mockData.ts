
import { Song, AnalyticsData } from '../types';

const sampleLyrics = [
  { time: 0, text: "[Instrumental Intro]" },
  { time: 10, text: "Welcome to the digital neon gravity" },
  { time: 15, text: "Falling through the waves of teal identity" },
  { time: 20, text: "Pulse of violet in the veins of history" },
  { time: 25, text: "Unlocking secrets of the cosmic mystery" },
  { time: 30, text: "We are the gravity, the premium frequency" },
  { time: 35, text: "Flowing in a world of pure transparency" }
];

export const mockSongs: Song[] = [
  {
    id: '1',
    title: 'Neon Gravity',
    artist: 'Lumino Flow',
    album: 'Deep Teal Dreams',
    coverUrl: 'https://picsum.photos/seed/music1/400/400',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    duration: 372,
    energy: 0.8,
    mood: 0.9,
    bitrate: '320kbps',
    lyrics: sampleLyrics
  },
  {
    id: '2',
    title: 'Ether Drift',
    artist: 'Violet Pulse',
    album: 'Zero Point',
    coverUrl: 'https://picsum.photos/seed/music2/400/400',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    duration: 412,
    energy: 0.3,
    mood: 0.4,
    bitrate: '320kbps',
    lyrics: sampleLyrics
  },
  {
    id: '3',
    title: 'Stellar Static',
    artist: 'Orbit 7',
    album: 'Cosmic Noise',
    coverUrl: 'https://picsum.photos/seed/music3/400/400',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    duration: 345,
    energy: 0.9,
    mood: 0.2,
    bitrate: '320kbps',
    lyrics: sampleLyrics
  },
  {
    id: '4',
    title: 'Midnight Oasis',
    artist: 'Echo Deep',
    album: 'Chill Horizons',
    coverUrl: 'https://picsum.photos/seed/music4/400/400',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    duration: 298,
    energy: 0.1,
    mood: 0.6,
    bitrate: '320kbps',
    lyrics: sampleLyrics
  }
];

export const mockAnalytics: AnalyticsData[] = [
  { timestamp: '00:00', listens: 120, engagement: 45 },
  { timestamp: '04:00', listens: 45, engagement: 30 },
  { timestamp: '08:00', listens: 230, engagement: 67 },
  { timestamp: '12:00', listens: 890, engagement: 88 },
  { timestamp: '16:00', listens: 1240, engagement: 95 },
  { timestamp: '20:00', listens: 980, engagement: 72 }
];
