
export interface LyricLine {
  time: number;
  text: string;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  coverUrl: string;
  audioUrl: string;
  duration: number;
  energy: number; // X axis
  mood: number;   // Y axis
  bitrate: '320kbps' | '1411kbps';
  lyrics?: LyricLine[];
  isDraft?: boolean;
}

export interface AppConfig {
  platformName: string;
  primaryColor: string; // Hex for Teal
  secondaryColor: string; // Hex for Violet
  enableKaraoke: boolean;
  enableSpatial: boolean;
  maintenanceMode: boolean;
}

export interface EnergyCoords {
  x: number;
  y: number;
}

export interface Playlist {
  id: string;
  name: string;
  createdBy: string;
  collaborators: string[];
  songs: string[];
  isCollaborative: boolean;
}

export interface AnalyticsData {
  timestamp: string;
  listens: number;
  engagement: number;
}

export type View = 'discovery' | 'library' | 'studio' | 'search' | 'playlists' | 'admin';
