
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Song, View, EnergyCoords, Playlist, AppConfig } from './types';
import { mockSongs } from './services/mockData';

interface MusicStore {
  currentSong: Song | null;
  isPlaying: boolean;
  volume: number;
  progress: number;
  queue: Song[];
  playlists: Playlist[];
  activeView: View;
  energyFilter: EnergyCoords;
  isHiRes: boolean;
  isSpatial: boolean;
  config: AppConfig;
  
  // Karaoke & Lyrics
  playbackSpeed: number;
  showLyrics: boolean;
  currentLyricIndex: number;
  
  // Actions
  setCurrentSong: (song: Song | null) => void;
  setIsPlaying: (playing: boolean) => void;
  setVolume: (volume: number) => void;
  setProgress: (progress: number) => void;
  setActiveView: (view: View) => void;
  setEnergyFilter: (coords: EnergyCoords) => void;
  toggleHiRes: () => void;
  toggleSpatial: () => void;
  nextSong: () => void;
  prevSong: () => void;
  setPlaybackSpeed: (speed: number) => void;
  toggleLyrics: () => void;
  
  // Admin & Content Actions
  addSong: (song: Song) => void;
  updateSong: (id: string, updates: Partial<Song>) => void;
  deleteSong: (id: string) => void;
  updateConfig: (updates: Partial<AppConfig>) => void;
}

export const useMusicStore = create<MusicStore>()(
  persist(
    (set, get) => ({
      currentSong: mockSongs[0],
      isPlaying: false,
      volume: 0.8,
      progress: 0,
      queue: mockSongs,
      playlists: [
        {
          id: 'p1',
          name: 'Late Night Chill',
          createdBy: 'User1',
          collaborators: ['User2'],
          songs: ['1', '2'],
          isCollaborative: true
        }
      ],
      activeView: 'discovery',
      energyFilter: { x: 0.5, y: 0.5 },
      isHiRes: false,
      isSpatial: false,
      playbackSpeed: 1.0,
      showLyrics: false,
      currentLyricIndex: -1,
      
      config: {
        platformName: 'GRAVIMUSIC',
        primaryColor: '#2dd4bf',
        secondaryColor: '#8b5cf6',
        enableKaraoke: true,
        enableSpatial: true,
        maintenanceMode: false
      },

      setCurrentSong: (song) => set({ currentSong: song, progress: 0, currentLyricIndex: -1 }),
      setIsPlaying: (playing) => set({ isPlaying: playing }),
      setVolume: (volume) => set({ volume }),
      setProgress: (progress) => {
        const { currentSong } = get();
        let index = -1;
        if (currentSong?.lyrics) {
          for (let i = currentSong.lyrics.length - 1; i >= 0; i--) {
            if (currentSong.lyrics[i].time <= progress) {
              index = i;
              break;
            }
          }
        }
        set({ progress, currentLyricIndex: index });
      },
      setActiveView: (view) => set({ activeView: view }),
      setEnergyFilter: (coords) => set({ energyFilter: coords }),
      toggleHiRes: () => set((state) => ({ isHiRes: !state.isHiRes })),
      toggleSpatial: () => set((state) => ({ isSpatial: !state.isSpatial })),
      
      nextSong: () => {
        const { queue, currentSong } = get();
        if (!currentSong) return;
        const idx = queue.findIndex(s => s.id === currentSong.id);
        const nextIdx = (idx + 1) % queue.length;
        set({ currentSong: queue[nextIdx], progress: 0 });
      },
      
      prevSong: () => {
        const { queue, currentSong } = get();
        if (!currentSong) return;
        const idx = queue.findIndex(s => s.id === currentSong.id);
        const prevIdx = (idx - 1 + queue.length) % queue.length;
        set({ currentSong: queue[prevIdx], progress: 0 });
      },

      setPlaybackSpeed: (speed) => set({ playbackSpeed: speed }),
      toggleLyrics: () => set((state) => ({ showLyrics: !state.showLyrics })),

      addSong: (song) => set((state) => ({ queue: [song, ...state.queue] })),
      updateSong: (id, updates) => set((state) => ({
        queue: state.queue.map(s => s.id === id ? { ...s, ...updates } : s)
      })),
      deleteSong: (id) => set((state) => ({
        queue: state.queue.filter(s => s.id !== id)
      })),
      updateConfig: (updates) => set((state) => ({
        config: { ...state.config, ...updates }
      })),
    }),
    {
      name: 'gravimusic-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ 
        queue: state.queue, 
        playlists: state.playlists,
        config: state.config,
        isHiRes: state.isHiRes,
        volume: state.volume 
      }),
    }
  )
);

// Cross-Tab Sync: Listen for storage changes in other windows
window.addEventListener('storage', (event) => {
  if (event.key === 'gravimusic-storage') {
    // When the storage is updated from the Backend window, rehydrate the state
    useMusicStore.persist.rehydrate();
  }
});
