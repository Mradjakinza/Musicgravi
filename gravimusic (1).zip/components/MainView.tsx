
import React from 'react';
import { useMusicStore } from '../store';
import EnergyGrid from './EnergyGrid';
import { Play, Heart, MoreHorizontal, Clock, Sparkles, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const MainView: React.FC = () => {
  const { queue = [], currentSong, setCurrentSong, setIsPlaying, energyFilter, playlists = [] } = useMusicStore();

  // Filter logic based on energy grid
  const filteredSongs = queue.filter(song => {
    const dist = Math.sqrt(
      Math.pow(song.energy - energyFilter.x, 2) + 
      Math.pow(song.mood - energyFilter.y, 2)
    );
    return dist < 0.6;
  }).sort((a, b) => {
    const distA = Math.sqrt(Math.pow(a.energy - energyFilter.x, 2) + Math.pow(a.mood - energyFilter.y, 2));
    const distB = Math.sqrt(Math.pow(b.energy - energyFilter.x, 2) + Math.pow(b.mood - energyFilter.y, 2));
    return distA - distB;
  });

  // Simple Collaborative Filtering Mock
  const recommendations = queue.slice(0, 3); 

  return (
    <div className="flex-1 overflow-y-auto p-10 relative">
      <div 
        className="fixed inset-0 pointer-events-none transition-all duration-1000"
        style={{
          background: `radial-gradient(circle at 60% 40%, rgba(45, 212, 191, calc(var(--aura-intensity) * 0.15)), transparent 70%),
                       radial-gradient(circle at 20% 80%, rgba(139, 92, 246, calc(var(--aura-intensity) * 0.15)), transparent 70%)`
        }}
      />

      <header className="mb-10 flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black mb-2 tracking-tighter">Your Aura Sync</h2>
          <p className="text-gray-400 font-medium">Matching tracks to your current coordinates</p>
        </div>
        <div className="flex gap-4">
            <div className="neumorph-outset p-3 rounded-2xl flex items-center gap-4 border border-white/5 bg-[#011618]">
                <div className="flex -space-x-3">
                    <img src="https://i.pravatar.cc/150?u=1" className="w-8 h-8 rounded-full border-2 border-[#011618]" />
                    <img src="https://i.pravatar.cc/150?u=2" className="w-8 h-8 rounded-full border-2 border-[#011618]" />
                </div>
                <span className="text-xs font-bold">3 Friends Online</span>
            </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-4 space-y-8">
          <EnergyGrid />
          
          <div className="glass-panel p-6 rounded-3xl border border-white/10 relative overflow-hidden group">
            <div className="flex items-center gap-3 mb-4">
                <Sparkles size={18} className="text-[#2dd4bf]" />
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">AI For You</h4>
            </div>
            <div className="space-y-4">
                {recommendations.map(song => (
                    <div key={song.id} className="flex items-center gap-3 group/item cursor-pointer" onClick={() => setCurrentSong(song)}>
                        <img src={song.coverUrl} className="w-12 h-12 rounded-xl" />
                        <div className="flex-1 min-w-0">
                            <p className="font-bold text-sm truncate group-hover/item:text-[#2dd4bf] transition-colors">{song.title}</p>
                            <p className="text-xs text-gray-500 truncate">{song.artist}</p>
                        </div>
                        <Play size={14} className="opacity-0 group-hover/item:opacity-100 text-[#2dd4bf]" />
                    </div>
                ))}
            </div>
          </div>

          <div className="glass-panel p-6 rounded-3xl border border-white/10 bg-gradient-to-br from-[#8b5cf6]/10 to-transparent">
             <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <Users size={18} className="text-[#8b5cf6]" />
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Collab Sessions</h4>
                </div>
                <button className="text-[10px] text-[#8b5cf6] font-bold">VIEW ALL</button>
             </div>
             {playlists.filter(p => p.isCollaborative).map(p => (
                <div key={p.id} className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-pointer">
                    <p className="font-bold text-sm mb-1">{p.name}</p>
                    <p className="text-[10px] text-gray-500">{p.collaborators.length + 1} Contributors</p>
                </div>
             ))}
          </div>
        </div>

        <div className="lg:col-span-8">
          <div className="glass-panel rounded-3xl overflow-hidden border border-white/5">
            <div className="grid grid-cols-12 px-6 py-4 text-[10px] uppercase font-bold text-gray-500 border-b border-white/5">
              <div className="col-span-1">#</div>
              <div className="col-span-6">Title</div>
              <div className="col-span-3">Album</div>
              <div className="col-span-2 text-right"><Clock size={14} className="ml-auto" /></div>
            </div>

            <div className="divide-y divide-white/5">
              <AnimatePresence mode="popLayout">
                {filteredSongs.map((song, idx) => (
                  <motion.div
                    key={song.id}
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3 }}
                    onClick={() => {
                      setCurrentSong(song);
                      setIsPlaying(true);
                    }}
                    className={`grid grid-cols-12 px-6 py-4 items-center group cursor-pointer transition-colors ${
                      currentSong?.id === song.id ? 'bg-white/10' : 'hover:bg-white/5'
                    }`}
                  >
                    <div className="col-span-1 text-sm font-medium text-gray-500">
                      {currentSong?.id === song.id ? (
                        <div className="w-3 h-3 bg-[#2dd4bf] rounded-full animate-pulse shadow-[0_0_10px_#2dd4bf]" />
                      ) : (
                        idx + 1
                      )}
                    </div>
                    <div className="col-span-6 flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg overflow-hidden relative">
                        <img src={song.coverUrl} className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <Play size={16} fill="white" />
                        </div>
                      </div>
                      <div>
                        <div className={`font-semibold text-sm ${currentSong?.id === song.id ? 'text-[#2dd4bf]' : 'text-white'}`}>
                          {song.title}
                        </div>
                        <div className="text-xs text-gray-400">{song.artist}</div>
                      </div>
                    </div>
                    <div className="col-span-3 text-xs text-gray-400 truncate">{song.album}</div>
                    <div className="col-span-2 text-right text-xs text-gray-500 flex items-center justify-end gap-4">
                      <Heart size={14} className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-[#8b5cf6]" />
                      <span>{Math.floor(song.duration / 60)}:{String(song.duration % 60).padStart(2, '0')}</span>
                      <MoreHorizontal size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
          
          {filteredSongs.length === 0 && (
            <div className="text-center py-20 bg-white/5 rounded-3xl border border-dashed border-white/10">
                <p className="text-gray-500">No tracks match your current coordinates. Try adjusting the Energy Grid.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainView;
