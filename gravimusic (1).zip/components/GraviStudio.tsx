
import React, { useState, useRef } from 'react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, AreaChart, Area, CartesianGrid } from 'recharts';
import { mockAnalytics } from '../services/mockData';
import { Plus, Download, TrendingUp, Users, Music, Upload, Link, X, CheckCircle } from 'lucide-react';
import { useMusicStore } from '../store';
import { Song } from '../types';

const GraviStudio: React.FC = () => {
  const { queue, addSong } = useMusicStore();
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    artist: '',
    album: '',
    sourceType: 'file' as 'file' | 'link',
    externalUrl: ''
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let audioUrl = '';
    if (formData.sourceType === 'file' && selectedFile) {
      audioUrl = URL.createObjectURL(selectedFile);
    } else {
      audioUrl = formData.externalUrl;
    }

    if (!audioUrl) return;

    const newSong: Song = {
      id: Date.now().toString(),
      title: formData.title || (selectedFile ? selectedFile.name : 'Unknown Track'),
      artist: formData.artist || 'Unknown Artist',
      album: formData.album || 'Unknown Album',
      coverUrl: `https://picsum.photos/seed/${Date.now()}/400/400`,
      audioUrl: audioUrl,
      duration: 0, // In real app, we'd get this from metadata
      energy: Math.random(),
      mood: Math.random(),
      bitrate: '320kbps'
    };

    addSong(newSong);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setShowAddModal(false);
      setFormData({ title: '', artist: '', album: '', sourceType: 'file', externalUrl: '' });
      setSelectedFile(null);
    }, 1500);
  };

  return (
    <div className="flex-1 overflow-y-auto p-10 z-10">
      <header className="mb-10 flex justify-between items-center">
        <div>
          <h2 className="text-4xl font-black mb-2 tracking-tighter">GraviStudio</h2>
          <p className="text-gray-400 font-medium">Artist Dashboard & Heatmap Analytics</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-r from-[#8b5cf6] to-[#2dd4bf] px-6 py-3 rounded-2xl font-bold text-[#011618] flex items-center gap-2 hover:scale-105 transition-transform shadow-xl"
        >
          <Plus size={20} />
          Add Track
        </button>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
        {[
            { label: 'Total Streams', value: '1.2M', icon: Music, color: '#2dd4bf' },
            { label: 'Avg Engagement', value: '84%', icon: TrendingUp, color: '#8b5cf6' },
            { label: 'Active Listeners', value: '12.4K', icon: Users, color: '#f59e0b' }
        ].map((stat, i) => (
            <div key={i} className="glass-panel p-6 rounded-3xl border border-white/10 flex items-center justify-between">
                <div>
                    <p className="text-[10px] uppercase font-bold text-gray-500 tracking-widest mb-1">{stat.label}</p>
                    <p className="text-3xl font-black">{stat.value}</p>
                </div>
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-white/5" style={{ color: stat.color }}>
                    <stat.icon size={24} />
                </div>
            </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
        <div className="glass-panel p-8 rounded-3xl border border-white/10">
          <h3 className="font-bold mb-6">Stream Heatmap</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockAnalytics}>
                <defs>
                  <linearGradient id="colorListen" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="timestamp" axisLine={false} tickLine={false} tick={{fill: '#4b5563', fontSize: 10}} />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#011618', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                />
                <Area type="monotone" dataKey="listens" stroke="#2dd4bf" fillOpacity={1} fill="url(#colorListen)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-8 rounded-3xl border border-white/10">
          <h3 className="font-bold mb-6">Engagement Ratio</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mockAnalytics}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="timestamp" axisLine={false} tickLine={false} tick={{fill: '#4b5563', fontSize: 10}} />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#011618', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                />
                <Bar dataKey="engagement" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Asset Table */}
      <div className="glass-panel rounded-3xl border border-white/10 overflow-hidden">
        <div className="p-6 border-b border-white/5 flex justify-between items-center">
            <h3 className="font-bold">Track Catalog</h3>
            <button className="text-sm text-[#2dd4bf] flex items-center gap-2">
                <Download size={16} /> Export CSV
            </button>
        </div>
        <table className="w-full text-left">
          <thead className="text-[10px] uppercase text-gray-500 font-bold bg-white/5">
            <tr>
              <th className="px-6 py-3">Track Name</th>
              <th className="px-6 py-3">Bitrate</th>
              <th className="px-6 py-3">Status</th>
              <th className="px-6 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {queue.map((song) => (
              <tr key={song.id} className="hover:bg-white/5 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <img src={song.coverUrl} className="w-8 h-8 rounded shadow" />
                    <div>
                      <p className="text-sm font-bold">{song.title}</p>
                      <p className="text-xs text-gray-500">{song.artist}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 rounded-md bg-white/5 text-[10px] font-bold text-blue-400 border border-blue-400/20">
                    {song.bitrate}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-xs text-gray-400">Live</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="text-xs text-[#2dd4bf] font-bold opacity-0 group-hover:opacity-100 transition-opacity">Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Track Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
          <div className="glass-panel w-full max-w-xl rounded-[2.5rem] border border-white/10 p-10 relative overflow-hidden">
            <button 
              onClick={() => setShowAddModal(false)}
              className="absolute top-6 right-6 p-2 text-gray-500 hover:text-white transition-colors"
            >
              <X size={24} />
            </button>

            {isSuccess ? (
              <div className="py-20 flex flex-col items-center justify-center animate-bounce">
                <CheckCircle size={64} className="text-[#2dd4bf] mb-4" />
                <h3 className="text-2xl font-bold">Track Added!</h3>
                <p className="text-gray-400 mt-2">Updating your catalog...</p>
              </div>
            ) : (
              <>
                <h3 className="text-2xl font-black mb-8">Add New Track</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-gray-500 ml-1">Track Title</label>
                      <input 
                        required
                        type="text" 
                        value={formData.title}
                        onChange={e => setFormData({...formData, title: e.target.value})}
                        placeholder="Song Name"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 outline-none focus:border-[#2dd4bf]/50 transition-colors"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-gray-500 ml-1">Artist Name</label>
                      <input 
                        required
                        type="text" 
                        value={formData.artist}
                        onChange={e => setFormData({...formData, artist: e.target.value})}
                        placeholder="Who's performing?"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 outline-none focus:border-[#8b5cf6]/50 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="flex bg-white/5 p-1 rounded-2xl border border-white/5">
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, sourceType: 'file'})}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${formData.sourceType === 'file' ? 'bg-white/10 text-[#2dd4bf]' : 'text-gray-500'}`}
                    >
                      <Upload size={18} /> File
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData({...formData, sourceType: 'link'})}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all ${formData.sourceType === 'link' ? 'bg-white/10 text-[#2dd4bf]' : 'text-gray-500'}`}
                    >
                      <Link size={18} /> Link
                    </button>
                  </div>

                  {formData.sourceType === 'file' ? (
                    <div 
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-white/10 rounded-3xl py-12 flex flex-col items-center justify-center cursor-pointer hover:border-[#2dd4bf]/30 hover:bg-white/5 transition-all"
                    >
                      <Music size={32} className="text-gray-500 mb-3" />
                      <p className="text-sm font-bold">{selectedFile ? selectedFile.name : 'Select MP3 File'}</p>
                      <p className="text-[10px] text-gray-500 mt-1">Lossless FLAC or MP3 supported</p>
                      <input 
                        ref={fileInputRef}
                        type="file" 
                        accept="audio/*" 
                        onChange={handleFileChange}
                        className="hidden" 
                      />
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <label className="text-[10px] uppercase font-bold text-gray-500 ml-1">External Audio URL</label>
                      <input 
                        required
                        type="url" 
                        value={formData.externalUrl}
                        onChange={e => setFormData({...formData, externalUrl: e.target.value})}
                        placeholder="https://example.com/song.mp3"
                        className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 outline-none focus:border-[#2dd4bf]/50 transition-colors"
                      />
                    </div>
                  )}

                  <button 
                    type="submit"
                    className="w-full bg-[#2dd4bf] text-[#011618] font-bold py-4 rounded-2xl shadow-xl shadow-[#2dd4bf]/20 hover:scale-[1.02] active:scale-[0.98] transition-transform"
                  >
                    Sync to Universe
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GraviStudio;
