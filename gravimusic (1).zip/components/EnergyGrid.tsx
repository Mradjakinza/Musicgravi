
import React, { useState, useRef } from 'react';
import { useMusicStore } from '../store';
import { motion } from 'framer-motion';

const EnergyGrid: React.FC = () => {
  const { energyFilter, setEnergyFilter } = useMusicStore();
  const gridRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleUpdate = (e: React.MouseEvent | React.TouchEvent) => {
    if (!gridRef.current) return;
    const rect = gridRef.current.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    
    let x = (clientX - rect.left) / rect.width;
    let y = 1 - (clientY - rect.top) / rect.height; // Invert Y for Mood (Bottom = Sad, Top = Happy)
    
    x = Math.max(0, Math.min(1, x));
    y = Math.max(0, Math.min(1, y));
    
    setEnergyFilter({ x, y });
  };

  return (
    <div className="relative p-6 glass-panel rounded-3xl overflow-hidden mb-8 group">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h3 className="text-lg font-bold">Energy Grid</h3>
          <p className="text-xs text-gray-500">Tune the gravity of your stream</p>
        </div>
        <div className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] uppercase font-bold text-[#2dd4bf]">
          Smart Mood AI
        </div>
      </div>

      <div 
        ref={gridRef}
        className="relative h-64 bg-[#011618] rounded-2xl border border-white/5 cursor-crosshair overflow-hidden neumorph-inset"
        onMouseDown={() => setIsDragging(true)}
        onMouseUp={() => setIsDragging(false)}
        onMouseLeave={() => setIsDragging(false)}
        onMouseMove={(e) => isDragging && handleUpdate(e)}
        onClick={handleUpdate}
      >
        {/* Grid lines */}
        <div className="absolute inset-0 grid grid-cols-4 grid-rows-4 opacity-5 pointer-events-none">
          {[...Array(16)].map((_, i) => (
            <div key={i} className="border border-white" />
          ))}
        </div>

        {/* Labels */}
        <span className="absolute top-4 left-1/2 -translate-x-1/2 text-[10px] font-bold text-gray-600 uppercase">Happy</span>
        <span className="absolute bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-bold text-gray-600 uppercase">Sad</span>
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-600 uppercase -rotate-90">Chill</span>
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-bold text-gray-600 uppercase rotate-90">Energetic</span>

        {/* Reticle */}
        <motion.div 
          className="absolute w-10 h-10 -ml-5 -mb-5 rounded-full border-2 border-[#8b5cf6] flex items-center justify-center bg-[#8b5cf6]/20 shadow-[0_0_20px_rgba(139,92,246,0.4)] pointer-events-none"
          animate={{
            left: `${energyFilter.x * 100}%`,
            bottom: `${energyFilter.y * 100}%`,
          }}
          transition={{ type: 'spring', damping: 20, stiffness: 200 }}
        >
          <div className="w-2 h-2 rounded-full bg-white" />
        </motion.div>
        
        {/* Glow effect based on position */}
        <div 
          className="absolute inset-0 opacity-20 transition-all pointer-events-none"
          style={{
            background: `radial-gradient(circle at ${energyFilter.x * 100}% ${(1 - energyFilter.y) * 100}%, #2dd4bf, transparent 50%)`
          }}
        />
      </div>
    </div>
  );
};

export default EnergyGrid;
