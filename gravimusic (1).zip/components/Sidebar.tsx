
import React from 'react';
import { Home, Search, Library, LayoutDashboard, Settings, LogOut, Radio } from 'lucide-react';
import { useMusicStore } from '../store';
import { View } from '../types';

const Sidebar: React.FC = () => {
  const { activeView, setActiveView, config } = useMusicStore();

  const NavItem = ({ icon: Icon, label, view }: { icon: any, label: string, view: View }) => (
    <button
      onClick={() => setActiveView(view)}
      className={`flex items-center gap-4 w-full p-3 rounded-xl transition-all duration-300 ${
        activeView === view 
        ? 'bg-gradient-to-r from-[#8b5cf6]/20 to-[#2dd4bf]/20 text-white shadow-lg border border-white/10' 
        : 'text-gray-400 hover:text-white hover:bg-white/5'
      }`}
    >
      <Icon size={20} className={activeView === view ? 'text-[#2dd4bf]' : ''} />
      <span className="font-medium text-sm">{label}</span>
    </button>
  );

  return (
    <div className="w-64 h-full glass-panel border-r border-white/5 flex flex-col p-6 z-20">
      <div className="flex items-center gap-3 mb-12 px-2">
        <div className="w-10 h-10 bg-[#8b5cf6] rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.5)]">
          <Radio className="text-white" size={24} />
        </div>
        <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-[#8b5cf6] to-[#2dd4bf] bg-clip-text text-transparent">
          {config.platformName}
        </h1>
      </div>

      <div className="flex-1 space-y-4">
        <div className="space-y-1">
          <p className="text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-3 px-3">Menu</p>
          <NavItem icon={Home} label="Discovery" view="discovery" />
          <NavItem icon={Search} label="Search" view="search" />
          <NavItem icon={Library} label="My Library" view="library" />
        </div>

        <div className="space-y-1 pt-6">
          <p className="text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-3 px-3">Artist Tools</p>
          <NavItem icon={LayoutDashboard} label="GraviStudio" view="studio" />
        </div>
      </div>

      <div className="mt-auto space-y-4 border-t border-white/5 pt-6">
        <button className="flex items-center gap-4 w-full p-3 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 transition-colors">
          <Settings size={20} />
          <span className="font-medium text-sm">Settings</span>
        </button>
        <button className="flex items-center gap-4 w-full p-3 rounded-xl text-red-400/80 hover:text-red-400 hover:bg-red-500/5 transition-colors">
          <LogOut size={20} />
          <span className="font-medium text-sm">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
