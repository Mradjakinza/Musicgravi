
import React from 'react';
import AdminView from './AdminView';
import { ShieldCheck, Activity, Database, Settings, LogOut, Terminal } from 'lucide-react';

const AdminApp: React.FC = () => {
  return (
    <div className="flex h-screen w-screen bg-[#020817] text-slate-200">
      {/* Backend Sidebar */}
      <aside className="w-72 border-r border-slate-800 flex flex-col p-8 bg-[#020617]">
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <ShieldCheck className="text-white" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-black text-white tracking-tighter">GRAVICORE</h1>
            <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">Backend Engine</p>
          </div>
        </div>

        <nav className="flex-1 space-y-2">
          <button className="flex items-center gap-4 w-full p-4 rounded-xl bg-indigo-500/10 text-indigo-400 font-bold border border-indigo-500/20">
            <Activity size={20} />
            <span>Dashboard</span>
          </button>
          <button className="flex items-center gap-4 w-full p-4 rounded-xl text-slate-500 hover:text-white hover:bg-white/5 transition-all">
            <Database size={20} />
            <span>Asset Manager</span>
          </button>
          <button className="flex items-center gap-4 w-full p-4 rounded-xl text-slate-500 hover:text-white hover:bg-white/5 transition-all">
            <Settings size={20} />
            <span>System Config</span>
          </button>
          <button className="flex items-center gap-4 w-full p-4 rounded-xl text-slate-500 hover:text-white hover:bg-white/5 transition-all">
            <Terminal size={20} />
            <span>API Logs</span>
          </button>
        </nav>

        <div className="mt-auto pt-8 border-t border-slate-800">
          <button className="flex items-center gap-4 w-full p-4 rounded-xl text-red-400/80 hover:text-red-400 hover:bg-red-400/5 transition-all">
            <LogOut size={20} />
            <span className="font-bold text-sm">Terminate Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col bg-gradient-to-br from-[#020817] to-[#0f172a] overflow-hidden">
        <div className="h-16 border-b border-slate-800/50 flex items-center justify-between px-10 bg-slate-900/20">
            <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                <span className="text-[10px] font-bold text-slate-500 uppercase">Live Node: US-EAST-1</span>
            </div>
            <div className="flex items-center gap-6">
                <span className="text-xs text-slate-500">Last Sync: Just now</span>
                <div className="w-8 h-8 rounded-full bg-slate-700 border border-slate-600 flex items-center justify-center text-[10px] font-black">AD</div>
            </div>
        </div>
        <AdminView />
      </main>
    </div>
  );
};

export default AdminApp;
